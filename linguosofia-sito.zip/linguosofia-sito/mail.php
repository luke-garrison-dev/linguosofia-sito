<?php
/**
 * Linguosofia — modulo di contatto.
 * Invio sicuro verso linguosofia1@gmail.com (PHP 7.4+).
 */
declare(strict_types=1);

const MAIL_TO = 'linguosofia1@gmail.com';
const MAX_ATTACH = 5 * 1024 * 1024;
const ALLOWED_EXT = array('pdf', 'doc', 'docx', 'odt', 'rtf', 'txt', 'xlsx', 'xls', 'ppt', 'pptx');

function wants_json()
{
    $accept = isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : '';
    return strpos($accept, 'application/json') !== false;
}

function respond($ok, $error = '', $code = 200)
{
    if ($ok) {
        http_response_code(200);
    } else {
        http_response_code($code);
    }
    if (wants_json()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok' => (bool) $ok, 'error' => $error));
        exit;
    }
    $lang = isset($_POST['lang']) ? strtolower((string) $_POST['lang']) : 'it';
    if (!in_array($lang, array('it', 'en', 'es', 'ru'), true)) {
        $lang = 'it';
    }
    $q = $ok ? 'sent=1' : 'error=1';
    header('Location: ' . $lang . '/contatti.html?' . $q);
    exit;
}

function header_safe($s)
{
    $s = str_replace(array("\r", "\n", "\0"), '', (string) $s);
    return trim($s);
}

if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Method Not Allowed';
    exit;
}

if (trim((string) (isset($_POST['website']) ? $_POST['website'] : '')) !== '') {
    respond(true);
}

$name = trim((string) (isset($_POST['name']) ? $_POST['name'] : ''));
$email = trim((string) (isset($_POST['email']) ? $_POST['email'] : ''));
$subject = trim((string) (isset($_POST['subject']) ? $_POST['subject'] : ''));
$message = trim((string) (isset($_POST['message']) ? $_POST['message'] : ''));

if ($name === '' || $email === '' || $subject === '' || $message === '') {
    respond(false, 'required', 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || preg_match('/[\r\n]/', $email)) {
    respond(false, 'email', 400);
}
if (strlen($name) > 200 || strlen($subject) > 200 || strlen($message) > 20000) {
    respond(false, 'required', 400);
}

$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0';
$rateFile = sys_get_temp_dir() . '/linguosofia_mail_' . hash('sha256', $ip);
$now = time();
$hits = array();
if (is_file($rateFile)) {
    $raw = (string) file_get_contents($rateFile);
    foreach (explode("\n", $raw) as $line) {
        $t = (int) $line;
        if ($t > $now - 3600) {
            $hits[] = $t;
        }
    }
}
if (count($hits) >= 8) {
    respond(false, 'send', 429);
}
$hits[] = $now;
@file_put_contents($rateFile, implode("\n", $hits), LOCK_EX);

$safeName = header_safe($name);
$safeEmail = header_safe($email);
$safeSubject = header_safe($subject);
$bodyText = "Nome / Name: {$safeName}\nE-mail: {$safeEmail}\n\n{$message}\n";

$boundary = '=_Ling' . bin2hex(random_bytes(12));
$mime = array();
$mime[] = 'This is a multi-part message in MIME format.';
$mime[] = '--' . $boundary;
$mime[] = 'Content-Type: text/plain; charset=UTF-8';
$mime[] = 'Content-Transfer-Encoding: quoted-printable';
$mime[] = '';
$mime[] = quoted_printable_encode($bodyText);

$file = isset($_FILES['attachment']) ? $_FILES['attachment'] : null;
if (is_array($file) && isset($file['error']) && (int) $file['error'] !== UPLOAD_ERR_NO_FILE) {
    if ((int) $file['error'] !== UPLOAD_ERR_OK) {
        respond(false, 'send', 400);
    }
    if ((int) $file['size'] > MAX_ATTACH) {
        respond(false, 'send', 400);
    }
    $orig = isset($file['name']) ? (string) $file['name'] : 'file';
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXT, true)) {
        respond(false, 'send', 400);
    }
    $tmp = isset($file['tmp_name']) ? (string) $file['tmp_name'] : '';
    if (!is_uploaded_file($tmp)) {
        respond(false, 'send', 400);
    }
    $data = file_get_contents($tmp);
    if ($data === false) {
        respond(false, 'send', 500);
    }
    $fname = header_safe(basename($orig));
    $fname = str_replace(array('"', '\\'), '', $fname);
    $mime[] = '--' . $boundary;
    $mime[] = 'Content-Type: application/octet-stream; name="' . $fname . '"';
    $mime[] = 'Content-Transfer-Encoding: base64';
    $mime[] = 'Content-Disposition: attachment; filename="' . $fname . '"';
    $mime[] = '';
    $mime[] = chunk_split(base64_encode($data));
}

$mime[] = '--' . $boundary . '--';
$mime[] = '';

$host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'linguosofia.local';
$host = preg_replace('/[^a-z0-9.-]/i', '', $host);
if ($host === '') {
    $host = 'linguosofia.local';
}
$from = 'Linguosofia <no-reply@' . $host . '>';

$headers = array(
    'MIME-Version: 1.0',
    'Content-Type: multipart/mixed; boundary="' . $boundary . '"',
    'From: ' . $from,
    'Reply-To: ' . $safeEmail,
    'X-Mailer: Linguosofia-contact',
);

$encodedSubject = '=?UTF-8?B?' . base64_encode('[Linguosofia] ' . $safeSubject) . '?=';
$envelope = '-fno-reply@' . $host;
$sent = @mail(MAIL_TO, $encodedSubject, implode("\r\n", $mime), implode("\r\n", $headers), $envelope);

if (!$sent) {
    respond(false, 'send', 500);
}
respond(true);
