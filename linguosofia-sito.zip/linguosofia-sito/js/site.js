(() => {
  const CONSENT_KEY = "linguosofia_cookie_consent";
  const VISIT_COOKIE = "linguosofia_visite";
  const YEAR = 60 * 60 * 24 * 365;

  const qs = (s, el = document) => el.querySelector(s);
  const qsa = (s, el = document) => [...el.querySelectorAll(s)];

  function readConsent() {
    try {
      const v = localStorage.getItem(CONSENT_KEY);
      if (v === "accepted" || v === "rejected") return v;
    } catch (_) {}
    return null;
  }
  function writeCookie(name, value, maxAge) {
    const secure = location.protocol === "https:" ? "; Secure" : "";
    document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) +
      "; Max-Age=" + maxAge + "; Path=/; SameSite=Lax" + secure;
  }
  function readCookie(name) {
    const parts = document.cookie.split("; ");
    for (const part of parts) {
      const eq = part.indexOf("=");
      if (eq === -1) continue;
      if (decodeURIComponent(part.slice(0, eq)) === name) {
        return decodeURIComponent(part.slice(eq + 1));
      }
    }
    return null;
  }
  function recordVisit() {
    const today = new Date().toISOString().slice(0, 10);
    const raw = readCookie(VISIT_COOKIE);
    let count = 0, last = "";
    if (raw) {
      const bits = raw.split(".");
      count = parseInt(bits[0] || "0", 10) || 0;
      last = bits[1] || "";
    }
    if (last !== today) { count += 1; last = today; }
    writeCookie(VISIT_COOKIE, count + "." + last, YEAR);
  }
  function clearVisit() {
    const secure = location.protocol === "https:" ? "; Secure" : "";
    document.cookie = encodeURIComponent(VISIT_COOKIE) + "=; Max-Age=0; Path=/; SameSite=Lax" + secure;
  }
  function setConsent(value) {
    try { localStorage.setItem(CONSENT_KEY, value); } catch (_) {}
    if (value === "accepted") recordVisit();
    else clearVisit();
    renderCookie();
  }
  function reopenConsent() {
    try { localStorage.removeItem(CONSENT_KEY); } catch (_) {}
    renderCookie();
  }
  function renderCookie() {
    const box = qs("[data-cookie]");
    if (!box) return;
    const c = readConsent();
    const show = c === null;
    box.classList.toggle("show", show);
    document.body.style.paddingBottom = show ? "13rem" : "";
    if (c === "accepted") recordVisit();
  }

  const menuToggle = qs(".menu-toggle");
  const menuBtn = qs(".menu-btn");
  if (menuToggle && menuBtn) {
    const syncMenu = () => {
      const open = menuToggle.checked;
      menuBtn.setAttribute("aria-expanded", String(open));
      menuBtn.setAttribute("aria-label", open ? menuBtn.dataset.closeLabel || "" : menuBtn.dataset.openLabel || "");
    };
    menuBtn.setAttribute("role", "button");
    menuBtn.setAttribute("aria-controls", "mobile-panel");
    menuBtn.dataset.openLabel = menuBtn.getAttribute("aria-label") || "";
    menuToggle.addEventListener("change", syncMenu);
    syncMenu();
  }
  const langBtn = qs("[data-lang-toggle]");
  const langMenu = qs("[data-lang-menu]");
  if (langBtn && langMenu) {
    langBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const open = langMenu.classList.toggle("open");
      langBtn.setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("click", () => {
      langMenu.classList.remove("open");
      langBtn.setAttribute("aria-expanded", "false");
    });
  }

  qs("[data-cookie-accept]")?.addEventListener("click", () => setConsent("accepted"));
  qs("[data-cookie-reject]")?.addEventListener("click", () => setConsent("rejected"));
  qs("[data-cookie-manage]")?.addEventListener("click", reopenConsent);
  renderCookie();

  const carousel = qs("[data-carousel]");
  if (carousel) {
    const track = qs("[data-track]", carousel);
    const slides = qsa(".slide", carousel);
    const dots = qsa("[data-dot]", carousel);
    let i = 0, paused = false;
    const go = (n) => {
      i = (n + slides.length) % slides.length;
      track.style.transform = "translateX(-" + i * 100 + "%)";
      dots.forEach((d, k) => d.classList.toggle("on", k === i));
    };
    qs("[data-prev]", carousel)?.addEventListener("click", () => go(i - 1));
    qs("[data-next]", carousel)?.addEventListener("click", () => go(i + 1));
    dots.forEach((d, k) => d.addEventListener("click", () => go(k)));
    carousel.addEventListener("mouseenter", () => { paused = true; });
    carousel.addEventListener("mouseleave", () => { paused = false; });
    setInterval(() => { if (!paused) go(i + 1); }, 6500);
  }

  const form = qs("[data-contact-form]");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const data = new FormData(form);
      const name = String(data.get("name") || "").trim();
      const email = String(data.get("email") || "").trim();
      const subject = String(data.get("subject") || "").trim();
      const message = String(data.get("message") || "").trim();
      const file = data.get("attachment");
      const fileName = file instanceof File && file.size > 0 ? file.name : "";
      const err = qs("[data-form-error]", form);
      const ok = qs("[data-form-ok]", form);
      const required = form.dataset.errorRequired || "";
      const badEmail = form.dataset.errorEmail || "";
      if (!name || !email || !subject || !message) {
        if (err) err.textContent = required;
        if (ok) ok.hidden = true;
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        if (err) err.textContent = badEmail;
        if (ok) ok.hidden = true;
        return;
      }
      if (err) err.textContent = "";
      const body = [
        form.dataset.labelName + ": " + name,
        form.dataset.labelEmail + ": " + email,
        "",
        message,
        fileName ? "\n[" + form.dataset.labelFile + ": " + fileName + "]" : "",
      ].join("\n");
      location.href = "mailto:linguosofia1@gmail.com?subject=" +
        encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
      if (ok) {
        ok.hidden = false;
        ok.textContent = form.dataset.success + (fileName ? " " + form.dataset.successHint : "");
      }
    });
  }
})();
